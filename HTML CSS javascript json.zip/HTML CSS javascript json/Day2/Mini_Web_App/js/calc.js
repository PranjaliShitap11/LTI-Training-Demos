// function addition(fn,sn)
// {
//     firstNumber=parseFloat(fn.value);
//     secondNumber=parseFloat(sn.value);
//     result=firstNumber+secondNumber;
//     //alert('Addition is '+result);
//     document.getElementById("result").innerHTML='Addition is '+result;
// }
function subtraction(fn,sn)
{
    firstNumber=parseFloat(fn.value);
    secondNumber=parseFloat(sn.value);
    result=firstNumber-secondNumber;
    //alert('Addition is '+result);
    document.getElementById("result").innerHTML='Subtraction is '+result;
}
// function addition()
// {
//     var fn=parseFloat(document.getElementById("txtFN").value);
//     var sn=parseFloat(document.getElementById("txtSN").value);
//     var result=fn+sn;
//     document.getElementById("result").innerHTML='Addition is '+result;
// }

// function addition()
// {
//     var fn=parseFloat(document.forms[0].txtFN.value);
//     var sn=parseFloat(document.forms[0][1].value);
//     var result=fn+sn;
//     document.getElementById("result").innerHTML='Addition is '+result;
// }
function addition(calcForm)
{
    if(calcForm.checkValidity())
    {
    var fn=parseFloat(calcForm.txtFN.value);
    var sn=parseFloat(calcForm.txtSN.value);
    var result=fn+sn;
    alert("Addition is"+result);
    }

   
}

