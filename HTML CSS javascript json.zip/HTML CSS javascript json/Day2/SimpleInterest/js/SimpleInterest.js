function SimpleInt(principle,rate,year)
{
    principle=parseFloat(principle.value);
    rate=parseFloat(rate.value);
    year=parseFloat(year.value);
    result=(principle*year* rate)/100;
    //alert('Addition is '+result);
    document.getElementById("result").innerHTML='Simple Interest is '+result;
   
}

function clearMsg()
{
    document.getElementById("result").innerHTML='';
}