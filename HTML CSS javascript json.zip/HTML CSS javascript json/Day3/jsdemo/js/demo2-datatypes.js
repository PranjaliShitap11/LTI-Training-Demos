var anyType;
document.write("anytype: <b>"+anyType+"</b> typeof(anyType):<b><i> "+typeof(anyType)+"</b></i>");
anyType="LTI"
document.write("<br/>anytype: <b>"+anyType+"</b> typeof(anyType):<b><i> "+typeof(anyType)+"</b></i>");
anyType='P';
document.write("<br/>anytype: <b>"+anyType+"</b> typeof(anyType):<b><i> "+typeof(anyType)+"</b></i>");
anyType=123
document.write("<br/>anytype: <b>"+anyType+"</b> typeof(anyType):<b><i> "+typeof(anyType)+"</b></i>");
anyType=12.4
document.write("<br/>anytype: <b>"+anyType+"</b> typeof(anyType):<b><i> "+typeof(anyType)+"</b></i>");
anyType=true
document.write("<br/>anytype: <b>"+anyType+"</b> typeof(anyType):<b><i> "+typeof(anyType)+"</b></i>");
anyType=null
document.write("<br/>anytype: <b>"+anyType+"</b> typeof(anyType):<b><i> "+typeof(anyType)+"</b></i>");
