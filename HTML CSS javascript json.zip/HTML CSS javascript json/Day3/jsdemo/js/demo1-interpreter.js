//external javascript

document.write(1);
document.write(2);
document.write(3);

//declaring variable
var name;
document.write(name);