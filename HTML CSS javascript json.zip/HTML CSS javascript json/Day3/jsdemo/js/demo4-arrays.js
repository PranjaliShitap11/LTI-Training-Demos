var numbers = [];
var numbers = new Array();

var listofBoys = ["Harry", "Ron", "Neville"];
var listOfGirls = ["Luna", "Hermione", "Ginny"];

document.write("<h3>" + typeof (listofBoys) + "<h3>");
document.write("<h3>" + typeof (listOfGirls) + "<h3>");

document.write("<h3>" + listofBoys + "<h3>");
document.write("<h3>" + listOfGirls + "<h3>");

for (i = 0; i < listofBoys.length; i++) {
    document.write(listofBoys[i].toUpperCase() + "<br/>");
}

for (var name in listofBoys) {
    document.write(name + "<br/>")
}

for (var name of listOfGirls) {
    document.write(name.bold() + "<br>");
}

listofBoys.push("Draco");
document.write("Count of Boys" + listofBoys.length + "<br>");
    
listOfGirls.unshift("Tonks");

document.write("Count of girls" + listOfGirls.length + "<br>");
listOfGirls.pop();
document.write("Count of girls" + listOfGirls.length + "<br>");
listofBoys.shift();
document.write("Count of girls" + listofBoys.length + "<br>");


listofBoys.unshift("Harry");
var combined=listOfGirls.concat(listofBoys);
document.write("Count of group:" + listofBoys.length + "<br>");

document.write(combined);

combined.sort();
document.write("<br/>"+combined);

combined.reverse();
document.write("<br/>"+combined);

//joining all elements with delimiter
var list=combined.join("#")
document.write("<br/>"+list);

document.write("<br/>"+listofBoys.slice(2,4));

document.write("<br/>"+combined);
combined.splice(2,3,["Cedric","Dobby","Dumbledore"]);
document.write("<br/>"+combined);

