function checkEvenOdd() {
    var num = parseInt(prompt("Enter a Number :", 0));
    var result = (num == 0) ? num + " is neither even nor odd.."
        : (num % 2 == 0) ? num + " is even number" : num + " is odd number..";
    document.getElementById("result").innerHTML = result;
}

function checkMax() {
    var num1 = parseInt(prompt("Enter first Number :", 0));
    var num2 = parseInt(prompt("Enter second Number :", 0));
    var result
    if (num1 == num2)
        result = "Both Numbers are equal."
    else if (num1 > num2)
        result = num1 + " is large number. "
    else
        result = num2 + " is large number. "
    document.getElementById("result").innerHTML = result;
}

function checkVowels() {
    var char = prompt("Enter a character :");
    var code=char.charCodeAt(char);
    console.log(code);
    var result;
    if ((code>=65 && code<=90)||(code>=92&&code<=122)) {
        
        switch (char.toUpperCase()) {

            case 'A':
            case 'E':
            case 'I':
            case 'O':
            case 'U':
                 result = char + " is VOWEL."
                 break;
            default:
                result = char + " is CONSONANT.";
                break;
        }
        
    }
    else
     result="Please enter a character";
     document.getElementById("result").innerHTML = result;
}
function findFactorial()
{
    var input= parseInt(prompt("Enter first Number :", 0));
    var factorial=1;
    var i=1;
    while(i<=input){
        factorial=factorial*i;
        i++;
    }
    document.getElementById("message").innerHTML = "Factorial="+factorial;
}
function PrintConsequtiveNumbers()
{
    var input= parseInt(prompt("Enter A Number :", 0));
    var i=1
    var result="";
    do
    {
        result=result+"</br>"+i;
        i++;
    }while(i<=input);
    document.getElementById("message").innerHTML = "Consecutive Series is as follows:<br/>"+result;
}
function sumOfNumbers()
{
    var input= parseInt(prompt("Enter first Number :", 0));
    var sum=0;
    for(i=0;i<=input;i++)
    {
        sum=sum+i;
    }
    document.getElementById("message").innerHTML = "Sum is: "+sum;
}