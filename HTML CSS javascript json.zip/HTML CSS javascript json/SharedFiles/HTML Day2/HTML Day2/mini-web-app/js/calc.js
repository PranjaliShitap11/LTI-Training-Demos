// user defined function
// 1) function takes parameter [recommended]
function addition(fn, sn){
    // Conversion from string to number
    // parseFloat() and parseInt()
    
    // Javascript is case sensitive language
    firstNumber = parseFloat(fn.value);
    secondNumber =  parseFloat(sn.value);

    result = firstNumber + secondNumber;

    // alert('Addition is '+result);

    // does not apply styles instead it prints styles
    // bcoz it treats styles as text
    // meaning it will parse text to text only
    // document.getElementById("result").innerText
    // ="<i>Addition is "+result+"</i>";

    // it will parse text to html 
    document.getElementById("result").innerHTML
    ="<i>Addition is "+result+"</i>";
}

// 2) function takes 0 parameters



// 3) function takes formObj as the parmeter [recommended]