function calculateSI(pa, roi, noy) {
    var si = parseFloat(pa.value) 
                * parseFloat(roi.value) 
                        * parseInt(noy.value) / 100; 
                        
//alert('Simple Interest is '+si);    
document.getElementById("lblResult").innerText  
            = 'Simple Interest is '+si;
         }