function SimpleInt(principle,rate,year)
{
    principle=parseFloat(principle.value);
    rate=parseFloat(rate.value);
    year=parseFloat(year.value);
    result=(principle*year* rate)/100;
    //alert('Addition is '+result);
    document.getElementById("result").innerHTML='Simple Interest is '+result;
   
}

function clearMsg()
{
    document.getElementById("result").innerHTML='';
}

function verifyUser()
{
    if(localStorage.getItem("username")==null)
    {
        window.open("../index.html")
    }
}

function logoff()
{
    if(localStorage.username)
    {
        localStorage.removeItem("username");
        localStorage.clear();
        window.open("../index.html");
    }
}