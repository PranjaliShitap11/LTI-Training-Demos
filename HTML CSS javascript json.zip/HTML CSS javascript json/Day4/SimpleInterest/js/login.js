//login.js is external javascript

function verifyLogin(loginForm)
{
    if(loginForm.checkValidity())
    {
        var username=loginForm.txtUN.value;
        var password=loginForm.txtPwd.value;
        if(username=="admin@gmail.com" && password=="123456")
        {
            alert("Login successful..");
            localStorage.setItem("username", username);
            window.open("../pages/SimpleInterest.html","_blank");
            
        }
        else
            alert("Invalid username or password..");
    }
}