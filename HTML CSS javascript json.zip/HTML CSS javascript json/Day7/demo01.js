var name = "Swati";
var PI = 3.142;
var HelloWorld = /** @class */ (function () {
    function HelloWorld() {
    }
    return HelloWorld;
}());
