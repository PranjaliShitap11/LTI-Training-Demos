let name:string="Swati";
const PI:number=3.142
class HelloWorld{
    
}
interface IHDFCBank{
    
}